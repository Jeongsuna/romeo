<?php

//flaw
$conn = new mysqli($servername, "admin", "admin1234!");

?>



