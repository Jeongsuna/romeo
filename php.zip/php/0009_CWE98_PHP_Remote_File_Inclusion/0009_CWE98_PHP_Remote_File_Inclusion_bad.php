<?php

$ dir = $ _GET [ 'module_name']; 
//flaw
include ($ dir. "/function.php");


?>



