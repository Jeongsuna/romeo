<?php

session_cache_expire(10);

session_start();

echo session_cache_expire();

?>



