<?php

session_start();

echo session_cache_expire();

?>

