<?php
//flaw
// ID:admin PW:dklfnai1!@!!
// ID:user1 PW:aknll11md
// ID:user2 PW:llkkjjadf!!
?>