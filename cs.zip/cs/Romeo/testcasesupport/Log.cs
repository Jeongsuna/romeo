﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Romeo.testcasesupport
{
    class Log
    {
        public static void WriteLine(string msg)
        {

        }
    }
}
